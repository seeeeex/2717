import React from "react";

function Warning() {
  return (
    <>
      <div className=" bg-red-300 dark:border-red-400 border-2  border-red-900 py-3 px-3 text-red-950 ml-5 mr-5 rounded-md">
        <h1>Your Data won't be stored until you Login! </h1>
      </div>
    </>
  );
}

export default Warning;
