import React from "react";

function Loader() {
  return (
    <div className=" bg-slate-300 h-[100vh] w-full flex justify-center items-center">
      <div className="loader"></div>
    </div>
  );
}

export default Loader;
